/*
 * TrackingColourPointTask.h
 *
 * Created: 3-12-2024 14:27:55
 *  Author: abe13
 */ 


#ifndef TRACKINGCOLOURPOINTTASK_H_
#define TRACKINGCOLOURPOINTTASK_H_

void DriveToNext(void);

#endif /* TRACKINGCOLOURPOINTTASK_H_ */