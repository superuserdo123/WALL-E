/*
 * TrackingColourPointTask.c
 *
 * Created: 3-12-2024 14:27:30
 *  Author: abe13
 */ 

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "hwconfig.h"

#include <stdio.h>
#include <util/delay.h>
#include <avr/eeprom.h>
#include <stdbool.h>

#include "DriverUSART.h"
#include "DriverMotor.h"


typedef struct{
	uint8_t x;
	uint8_t y;
	} Position;
	

Position colourPos[] = {{0,0},{0,0},{0,0}};
uint8_t PNT_ADDR[] = {(uint8_t *)PNT1_ADDR,(uint8_t *)PNT2_ADDR,(uint8_t *)PNT3_ADDR, (uint8_t *)CURRENTPOS_ADDR, (uint8_t *)CHARGE_PNT1_ADDR, (uint8_t *)CHARGE_PNT2_ADDR};

Position currentPos = {2,0};
Position chargingPos[] = {{0,0},{4,4}};
	
const uint8_t squareLength = 100;
const uint8_t gridLength = 5;

uint8_t currentAngle = 1; // 0/1/2/3 correlating to 0/90/180/270 counterclockwise
const float speed = 100.0;
const uint16_t drivingDelay = 1000;


char* determineColor(uint16_t c, uint16_t r, uint16_t g, uint16_t b);

void DriveToColourPoints(uint8_t pntNum)
{

	ReadEEPROM(false);
	DriveToPnt(pntNum);
	
}

void DriveToNext(void)
{
	FILE* stream = GetRoverStream();
	ReadEEPROM(false);
	uint8_t currentPoint = 1;

	for(int i=0; i<3; i++)
	{

		if(currentPos.x==colourPos[i].x && currentPos.y==colourPos[i].y)
		{
			currentPoint = i+1;
			fprintf(stream, "Current point: %d\r\n",currentPoint);
		}
	}
	
	currentPoint<3 ? DriveToPnt(currentPoint+1) : DriveToPnt(1);
	
}


void ReadEEPROM(bool sendToUART)
{

	uint8_t readVal;
	FILE* stream = GetRoverStream();
	
	for(int i=0; i<floor(sizeof(PNT_ADDR)/sizeof(PNT_ADDR[0])); i++)
	{
		eeprom_busy_wait();
		readVal = eeprom_read_byte(PNT_ADDR[i]); 
		if(i>3){
			chargingPos[i-4].x = readVal>>4;
			chargingPos[i-4].y = readVal&0b1111;
			if(sendToUART){
				fprintf(stream, "Reading from 0x%02x: x=%d, y=%d	(=charge point)\r\n", PNT_ADDR[i], chargingPos[i-4].x, chargingPos[i-4].y);
			}
		}
		else if(i>2){
			currentPos.x = readVal>>4;
			currentPos.y = readVal&0b1111;
			if(sendToUART){
				fprintf(stream, "Reading from 0x%02x: x=%d, y=%d	(=current position)\r\n", PNT_ADDR[i], currentPos.x, currentPos.y);
			}
		}else{
			colourPos[i].x = readVal>>4;
			colourPos[i].y = readVal&0b1111;
			if(sendToUART){
				fprintf(stream, "Reading from 0x%02x: x=%d, y=%d	(=colour point)\r\n", PNT_ADDR[i], colourPos[i].x, colourPos[i].y);
			}
		}
	}
	
}

void UpdateEEPROM(uint8_t pntNum, uint8_t x, uint8_t y)
{
	FILE* stream = GetRoverStream();
	if(x>gridLength | y>gridLength){
		fprintf(stream, "X or Y coordinate is out of range (%d x %d grid)\r\n",gridLength,gridLength);
		return;
	}
	uint8_t writeVal = (x<<4) | y;
	eeprom_write_byte(PNT_ADDR[pntNum-1], writeVal);
	if(pntNum>4){
		chargingPos[pntNum-5].x = x;
		chargingPos[pntNum-5].y = y;
	}
	else if(pntNum>3){
		currentPos.x = x;
		currentPos.y = y;
	}else{
		colourPos[pntNum-1].x = x;
		colourPos[pntNum-1].y = y;
	}
	fprintf(stream, "Writing to point %d: x=%d, y=%d\r\n", pntNum, x, y);
}


void DriveToPnt(uint8_t pntNum)
{
	FILE* stream = GetRoverStream();
	fprintf(stream,"PntNum: %d\r\n",pntNum);
	int8_t deltaX, deltaY = 0;
	int8_t tempDeltaX[2], tempDeltaY[2] = {0,0};
	
	if(pntNum<=3){
		deltaX = colourPos[pntNum-1].x - currentPos.x;
		deltaY = colourPos[pntNum-1].y - currentPos.y;
	}
	else{
		
		for(int i=0; i<=1; i++){
			tempDeltaX[i] = chargingPos[i].x - currentPos.x;
			tempDeltaY[i] = chargingPos[i].y - currentPos.y;
		}
		if(abs(tempDeltaX[0])+abs(tempDeltaY[0])<=abs(tempDeltaX[1])+abs(tempDeltaY[1])){
			deltaX = tempDeltaX[0];
			deltaY = tempDeltaY[0];
		}
		else{
			deltaX = tempDeltaX[1];
			deltaY = tempDeltaY[1];
		}		
	}

	int8_t xDir = deltaX/abs(deltaX);
	int8_t yDir = deltaY/abs(deltaY);
	uint8_t angleForX, angleForY;
	
	if(deltaX>0){
		angleForX = 2; //180 degrees
	}else{
		angleForX = 0; //0 degrees
	}
	int8_t rotForDeltaX = angleForX-currentAngle;
	
	if(deltaY>0){
		angleForY = 1; //90 degrees
	}else{
		angleForY = 3; //270 degrees
	}
	int8_t rotForDeltaY = angleForY-currentAngle;
	
	fprintf(stream, "deltaX: %d and deltaY: %d rotForDeltaX: %d and rotForDeltaY: %d\r\n",deltaX,deltaY,rotForDeltaX,rotForDeltaY);
	
	if(deltaX != 0){
		if(rotForDeltaX!= 0){
			fprintf(stream, "Rotating %d degrees\r\n",rotForDeltaX*90);
			RotateCenter((float) rotForDeltaX*90, speed);
			currentAngle = angleForX;
			_delay_ms(drivingDelay);
		}
		fprintf(stream, "Driving straight %d mm\r\n",deltaX*squareLength);
		DriveStraight((float) abs(deltaX)*squareLength, speed);
		rotForDeltaY = currentAngle-angleForY;
		if(deltaY!=0){
			_delay_ms(drivingDelay);
		}
	} 
	
	if(deltaY != 0){
		if(rotForDeltaY!=0){
			fprintf(stream, "Rotating %d degrees\r\n",rotForDeltaY*90);
			RotateCenter((float) rotForDeltaY*90, speed);
			currentAngle = angleForY;
			_delay_ms(drivingDelay);
		}
		fprintf(stream, "Driving straight %d mm\r\n",deltaY*squareLength);
		DriveStraight((float) abs(deltaY)*squareLength, speed);
	}
	
	fprintf(stream,"Done driving\r\n");
	
	if(pntNum<=3){
		UpdateEEPROM(4,colourPos[pntNum-1].x,colourPos[pntNum-1].y);
	}
	else if(abs(tempDeltaX[0])+abs(tempDeltaY[0])<=abs(tempDeltaX[1])+abs(tempDeltaY[1])){
		UpdateEEPROM(4,chargingPos[0].x,chargingPos[0].y);
	}
	else{
		UpdateEEPROM(4,chargingPos[1].x,chargingPos[1].y);
	}
	
	findColourPnt(stream);
}

void findColourPnt(FILE* stream)
{
	uint16_t c,r,g,b;
	DriverAdps9960Get(&c,&r,&g,&b);
	char* color = determineColor(c,r,g,b);
	
	/*
	uint8_t i = 1;
	uint8_t initDistance = 5;
	uint8_t distance = 5;

	while(strstr(color,"BACKGROUND"))
	{
		DriveStraight(distance,speed);
		color = determineColor(c,r,g,b);
		distance = initDistance*2+distance*i;
		i++;
	}
	*/
	fprintf (stream,"OK %d %d %d %d: %s\r\n",c,r,g,b,color);
	
}


char* determineColor(uint16_t c, uint16_t r, uint16_t g, uint16_t b)
{
	static char color[15];
	if(c >= 15800 && c <= 17900 && r >= 1400 && r <= 1850 && g >= 3750 && g <= 4500 && b >= 9800 && b <= 10950)
	{
		strcpy(color,"BLUE");
	}
	else if(c >= 11400 && c <= 13300 && r >= 5400 && r <= 6300 && g >= 2300 && g <= 2850 && b >= 2900 && b <= 3550)
	{
		strcpy(color,"RED");
	}
	else if(c >= 11800 && c <= 17300 && r >= 1450 && r <= 2650 && g >= 4900 && g <= 7550 && b >= 3800 && b <= 5750)
	{
		strcpy(color,"GREEN");
	}
	else
	{
		strcpy(color,"BACKGROUND");
	}
	return color;
}


void FindChargingPoints(void)
{
	DriveToPnt(4);
}

