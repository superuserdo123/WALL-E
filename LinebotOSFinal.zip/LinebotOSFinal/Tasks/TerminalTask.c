#include "TerminalTask.h"


#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#include "DriverPower.h"
#include "DriverMotor.h"
#include "MotionTask.h"
#include "GyroTask.h"
#include "RGBTask.h"
#include "ADCTask.h"
#include "DriverAdps9960.h"
#include "memmap.h"
#include "DriverUSART.h"
#include "TrackingColourPointTask.h"

#include <avr/pgmspace.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h> // added for isdigit function
#include <util/delay.h>
#include <stdbool.h>

#define MAX_PARS 3


//Private function prototypes
static void WorkerTerminal(void *pvParameters);
static void SplitCmd(FILE *stream, char *Data,char *Cmd,float *Pars);

//Function definitions
void InitTerminalTask()
{
	xTaskCreate( WorkerTerminal, "term", 1024, NULL, tskIDLE_PRIORITY+1, NULL );	
}


static void SplitCmd(FILE *stream, char *Data,char *Cmd,float *Pars)
{
	
	uint8_t a;
	char *ss;
	
	ss=strtok(Data," ");
	
	if (ss!=NULL) strcpy(Cmd,ss);
	for (a=0;a<MAX_PARS;a++) 
	{
		ss=strtok(NULL," ");
		if (ss!=NULL)
		{
			Pars[a]=atof(ss);
		}
		else
			Pars[a]=0.0;
	}
	

	//fprintf(stream, "Debug: Command: '%s', Pars: [%f, %f]\r\n", Cmd, Pars[0], Pars[1]);


}


static void WorkerTerminal(void *pvParameters)
{
	char sbuf[200]; //200
	float Pars[MAX_PARS];
	char Cmd[64];
	uint16_t c,r,g,b;
	char color[15];
	
	while (1)
	{
		
		FILE* stream = GetRoverStream();		
		//fprintf(stream, ">C://\r\n");
		if(fgets(sbuf,sizeof(sbuf),stream) != NULL){
			fprintf(stream, "%s\r\n", sbuf); //199
		}else{
			fprintf(stream, "No input\r\n");
			continue;
		}
	
		if(sbuf[0] == '\0' || sbuf[0] == '\n'){
			continue;
		}
		SplitCmd(stream,sbuf,Cmd,Pars);
		
		//Task list command
		if (strstr(Cmd,"help"))
		{
			fprintf(stream, "Command list:\r\n");
			fprintf(stream, "help :this help page\r\n");
			fprintf(stream, "tsklst :list FreeRTOS tasks\r\n");
			fprintf(stream, "memmap :show memory map\r\n");
			fprintf(stream, "drvstr distance speed :Drive straight over 'distance' mm at a speed of 'speed' mm/s\r\n");
			fprintf(stream, "rotctr angle speed :rotate 'angle' degrees around center of robot at a speed of 'speed' mm/s\r\n");
			fprintf(stream, "drvseg speed :follow line segment until end at a speed of 'speed' mm/s\r\n");
			fprintf(stream, "setled effect :set RGB led effect (see RGBTask.h)\r\n");
			fprintf(stream, "setmot leftmotor_pwm rightmotor_pwm :directly control motor pwm signal. Pwm is in a range of -4095 to 4095\r\n");
			fprintf(stream, "getenc :get motor encoder values\r\n");
			fprintf(stream, "getrgb :returns RGB light sensor values\r\n");
			fprintf(stream, "getgyr :returns gyroscope info in format 'yawrate (deg/s) yaw(deg)\r\n");
			fprintf(stream, "getadc :returns Analog channels in format 'left_line_sensor mid_line_sensor right_line_sensor potentiometer\r\n");
			fprintf(stream, "auxpwr state:'state'=1: turn on aux power net, 'state'=0: turn off aux power net\r\n");
			fprintf(stream, "read :read EEPROM x and y values\r\n");
			fprintf(stream, "update :update EEPROM x and y values\r\n");
			fprintf(stream, "drive :drive to specified measuring point\r\n");
			fprintf(stream, "drvToNext :drive to next measuring point\r\n");
			fprintf(stream, "OK\r\n");
		}
		else if (strstr(Cmd,"tsklst"))
		{
			vTaskGetRunTimeStats(sbuf);
			puts(sbuf);
		}
		else if (strstr(Cmd,"memmap"))
		{
			MemMap();
		}
		else if (strstr(Cmd,"drvstr"))
		{
			DriveStraight(Pars[0],Pars[1]);
			fprintf(stream,"OK\r\n");
		}
		else if (strstr(Cmd,"drvseg"))
		{
			DriveSegment(Pars[0]);
			fprintf(stream,"OK\r\n");
		}
		else if (strstr(Cmd,"rotctr"))
		{
			RotateCenter(Pars[0],Pars[1]);
			fprintf(stream,"OK\r\n");
		}
		else if (strstr(Cmd,"setled"))
		{
			//SetRGB(Pars[0]);
			DriverLedToggle((uint8_t) 0b11111111);
			fprintf(stream,"OK\r\n");
		}
		else if (strstr(Cmd,"setmot"))
		{
			DriverMotorSet((int16_t) Pars[0],(int16_t) Pars[1]);
			fprintf(stream,"OK\r\n");
		}
		else if (strstr(Cmd,"getenc"))
		{	
			EncoderStruct Encoder;
			Encoder=DriverMotorGetEncoder();
			fprintf (stream,"OK %d %d\r\n",Encoder.Cnt1,Encoder.Cnt2);
		}		
		else if (strstr(Cmd,"getrgb"))
		{
			DriverAdps9960Get(&c,&r,&g,&b);
			
			if(c >= 15800 && c <= 17900 && r >= 1400 && r <= 1850 && g >= 3750 && g <= 4500 && b >= 9800 && b <= 10950)
			{
				strcpy(color,"BLUE");
			}
			else if(c >= 11400 && c <= 13300 && r >= 5400 && r <= 6300 && g >= 2300 && g <= 2850 && b >= 2900 && b <= 3550)
			{
				strcpy(color,"RED");
			}
			else if(c >= 11800 && c <= 17300 && r >= 1450 && r <= 2650 && g >= 4900 && g <= 7550 && b >= 3800 && b <= 5750)
			{
				strcpy(color,"GREEN");
			}
			else
			{
				strcpy(color,"BACKGROUND");
			}

			fprintf (stream,"OK %d %d %d %d: %s\r\n",c,r,g,b,color);
		}
		else if (strstr(Cmd,"getgyr"))
		{
			float YawRate,Yaw;
			GyroGet(&YawRate,&Yaw);
			fprintf (stream,"OK %f %f\r\n",YawRate,Yaw);
		}
		else if (strstr(Cmd,"getadc"))
		{
			ADCStruct ADCData;
			ADCData=GetADCData();
			fprintf (stream,"OK %d %d %d %d\r\n",ADCData.PhotoL,ADCData.PhotoM,ADCData.PhotoR,ADCData.Potmeter);
		}
		else if (strstr(Cmd,"auxpwr"))
		{
			DriverPowerVccAuxSet((uint8_t) Pars[0]);
			fprintf(stream,"OK\r\n");
		}
		else if(strstr(Cmd,"read"))
		{
			ReadEEPROM(true);
			fprintf(stream,"OK\r\n");
		}
		else if(strstr(Cmd,"update"))
		{
			UpdateEEPROM((uint8_t) Pars[0], (uint8_t) Pars[1], (uint8_t) Pars[2]);
			fprintf(stream,"OK\r\n");
		}
		else if(strstr(Cmd,"2next"))
		{
			DriveToNext();
			fprintf(stream,"OK\r\n");
		}
		else if(strstr(Cmd,"drive"))
		{
			DriveToColourPoints((uint8_t) Pars[0]);
			fprintf(stream,"OK\r\n");
		}
		else if(strstr(Cmd,"charge"))
		{
			FindChargingPoints();
			fprintf(stream,"OK\r\n");
		}
		else
		{
			fprintf(stream,"OK\r\n");
		}
	}
}
