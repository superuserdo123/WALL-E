#include "DriverUSART.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include "hwconfig.h"

#include "FreeRTOS.h"
#include "queue.h"
#include "semphr.h"

static int stdio_putchar(char c, FILE * stream);
static int stdio_getchar(FILE *stream);
static FILE UsartStdio = FDEV_SETUP_STREAM(stdio_putchar, stdio_getchar,_FDEV_SETUP_RW);

QueueHandle_t UsartTxQueue;
QueueHandle_t UsartRxQueue;

static int Rover_PutChar(char c, FILE *stream);
static int Rover_GetChar(FILE *stream);
static FILE Rover_Stream = FDEV_SETUP_STREAM(Rover_PutChar, Rover_GetChar, _FDEV_SETUP_RW);

QueueHandle_t UsartRoverTxQueue;
QueueHandle_t UsartRoverRxQueue;

void DriverUSARTInit(void)
{
	UsartTxQueue=xQueueCreate(UART_QUEUE_LENGTH,sizeof(char));
	UsartRxQueue=xQueueCreate(UART_QUEUE_LENGTH,sizeof(char));
		
	USART_PORT.DIRSET=0b00001000;	
	USART_PORT.DIRCLR=0b00000100;
	
	USART.CTRLA=0b00010100;
	USART.CTRLB=0b00011000;
	USART.CTRLC=0b00000011;
	
	USART.BAUDCTRLA=0xE5; //BSEL=3301, BSCALE=-5 19200 baud
	USART.BAUDCTRLB=0xBC; 
	
	stdout=&UsartStdio;
	stdin=&UsartStdio;
	
	
	//Added
	
	UsartRoverTxQueue=xQueueCreate(UART_QUEUE_LENGTH,sizeof(char));
	UsartRoverRxQueue=xQueueCreate(UART_QUEUE_LENGTH,sizeof(char));
	
	USART_PORT_ROVER.DIRSET=0b00001000;
	USART_PORT_ROVER.DIRCLR=0b00000100;
	
	USART_ROVER.CTRLA=0b00010100;
	USART_ROVER.CTRLB=0b00011000;
	USART_ROVER.CTRLC=0b00000011;
	
	USART_ROVER.BAUDCTRLA=0xE5; //BSEL=3301, BSCALE=-5 19200 baud
	USART_ROVER.BAUDCTRLB=0xBC;

}


static int stdio_putchar(char c, FILE * stream)
{
	int res;
	char cbuf;

	xQueueSend(UsartTxQueue,&c,portMAX_DELAY);

	if (USART.STATUS & (1<<5))
	{
		xQueueReceive(UsartTxQueue,&cbuf,0);
		USART.DATA=cbuf;
	}
		
	return 0;
}
	
static int stdio_getchar(FILE *stream)
{
	char c;
	xQueueReceive(UsartRxQueue,&c,portMAX_DELAY);
	return c;
}

static int Rover_PutChar(char c, FILE *stream)
{
	int res;
	char cbuf;

	xQueueSend(UsartRoverTxQueue,&c,portMAX_DELAY);

	if (USART_ROVER.STATUS & (1<<5))
	{
		xQueueReceive(UsartRoverTxQueue,&cbuf,0);
		USART_ROVER.DATA=cbuf;
	}
	
	return 0;
}


static int Rover_GetChar(FILE *stream)
{
	char c;
	xQueueReceive(UsartRoverRxQueue,&c,portMAX_DELAY);
	return c;
}


ISR(USART_TXC_vect)
{
	char c;
	BaseType_t xHigherPriorityTaskWoken=pdFALSE;
	if (xQueueReceiveFromISR(UsartTxQueue,&c,&xHigherPriorityTaskWoken)==pdPASS)
	{
		USART.DATA=c;	
	}
	
	portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

ISR(USART_RXC_vect)
{
	char c;
	BaseType_t xHigherPriorityTaskWoken=pdFALSE;
	
	c=USART.DATA;
	xQueueSendToBackFromISR(UsartRxQueue,&c,&xHigherPriorityTaskWoken);
	portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
	
}


ISR(USART_TXC_vect_ROVER)
{
	char c;
	BaseType_t xHigherPriorityTaskWoken=pdFALSE;
	if (xQueueReceiveFromISR(UsartRoverTxQueue,&c,&xHigherPriorityTaskWoken)==pdPASS)
	{
		USART_ROVER.DATA=c;
	}
	
	portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

ISR(USART_RXC_vect_ROVER)
{
	char c;
	BaseType_t xHigherPriorityTaskWoken=pdFALSE;
	
	c=USART_ROVER.DATA;
	xQueueSendToBackFromISR(UsartRoverRxQueue,&c,&xHigherPriorityTaskWoken);
	portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
	
}

FILE* GetRoverStream(void)
{
	return &Rover_Stream;
}
