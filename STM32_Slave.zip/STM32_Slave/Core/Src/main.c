/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>

extern UART_HandleTypeDef huart2;

int _write(int file, char *ptr, int len)
{
    HAL_UART_Transmit(&huart2, (uint8_t *)ptr, len, HAL_MAX_DELAY);
    return len;
}

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
RTC_HandleTypeDef hrtc;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define BLE_I2C_ADDRESS 0x08 // I2C address of BLE module

#define SHT40_ADDRESS 0x44 << 1 // SHT40 sensor I2C address
#define LTR329_ADDRESS 0x29 << 1 // LTR-329 I2C address (left-aligned for STM32)
#define LTR329_CONTR_REG  0x80  // Control register
#define LTR329_MEAS_RATE  0x85  // Measurement rate register
#define LTR329_DATA_CH1_LOW  0x88 // CH1 data low byte
#define LTR329_DATA_CH1_HIGH 0x89 // CH1 data high byte
#define LTR329_DATA_CH0_LOW  0x8A // CH0 data low byte
#define LTR329_DATA_CH0_HIGH 0x8B // CH0 data high byte

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
I2C_HandleTypeDef hi2c3;

RTC_HandleTypeDef hrtc;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/* Example: 6 data strings to send */
static const char * dataList[2] = {
  "T:300,H:2330,B:100;",
  "IR:4000,VIR:10000;"
};

static uint8_t currentIndex = 0; // which data string to send next


uint8_t read_command[] = {0xFD}; // High precision no heater command
uint8_t sensor_data[6];          // Buffer for raw sensor data
float temperature, humidity;     // Temperature and humidity values

uint16_t visible_plus_ir = 0, ir = 0;


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_RTC_Init(void);
static void MX_I2C1_Init(void);
static void MX_I2C3_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */
void SendDataToBLE(const char* data);
void Enter_StandByMode(void);

void Measure(void);
void Read_SHT40(void); // Function to read SHT40 data
void LTR329_Init(void);
void Read_LTR329(uint16_t *visible_plus_ir, uint16_t *ir);

void DriveToNextPoint(void);

void TurnOnBLE(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_RTC_Init();
  MX_I2C1_Init();
  MX_I2C3_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
  printf("Start\r\n");

  //  RTC wake-up timer
  if (HAL_RTCEx_SetWakeUpTimer_IT(&hrtc, 500 * 1024, RTC_WAKEUPCLOCK_RTCCLK_DIV16, 0) != HAL_OK)
  {
	  Error_Handler();
  }
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	Measure();

	TurnOnBLE();

	HAL_Delay(1000);

	for (int i = 0; i < 2; i++)
	{
		SendDataToBLE(dataList[currentIndex]);
		HAL_Delay(100);
		currentIndex = (currentIndex + 1) % 2;
	}

	DriveToNextPoint();

	HAL_Delay(500);

	Enter_StandByMode();

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_LSE
                              |RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_10;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Enable MSI Auto calibration
  */
  HAL_RCCEx_EnableMSIPLLMode();
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00B07CB4;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief I2C3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C3_Init(void)
{

  /* USER CODE BEGIN I2C3_Init 0 */

  /* USER CODE END I2C3_Init 0 */

  /* USER CODE BEGIN I2C3_Init 1 */

  /* USER CODE END I2C3_Init 1 */
  hi2c3.Instance = I2C3;
  hi2c3.Init.Timing = 0x00B07CB4;
  hi2c3.Init.OwnAddress1 = 0;
  hi2c3.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c3.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c3.Init.OwnAddress2 = 0;
  hi2c3.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c3.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c3.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c3) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c3, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c3, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C3_Init 2 */

  /* USER CODE END I2C3_Init 2 */

}

/**
  * @brief RTC Initialization Function
  * @param None
  * @retval None
  */
static void MX_RTC_Init(void)
{

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */

  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
  hrtc.Init.AsynchPrediv = 127;
  hrtc.Init.SynchPrediv = 255;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutRemap = RTC_OUTPUT_REMAP_NONE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
  hrtc.Init.OutPutPullUp = RTC_OUTPUT_PULLUP_NONE;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }

  /** Enable the WakeUp
  */
  if (HAL_RTCEx_SetWakeUpTimer_IT(&hrtc, 0, RTC_WAKEUPCLOCK_RTCCLK_DIV16, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RTC_Init 2 */

  /* USER CODE END RTC_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */
  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(ENABLE_SENSOR_GPIO_Port, ENABLE_SENSOR_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(BLE_WAKE_GPIO_Port, BLE_WAKE_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin : ENABLE_SENSOR_Pin */
  GPIO_InitStruct.Pin = ENABLE_SENSOR_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(ENABLE_SENSOR_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : BLE_WAKE_Pin */
  GPIO_InitStruct.Pin = BLE_WAKE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(BLE_WAKE_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */


/**
  * @brief  Send data over I2C to the BLE module
  */
void SendDataToBLE(const char* data)
{
  uint8_t buffer[50] = {0};
  uint16_t length = (uint16_t)strlen(data);
  if (length >= sizeof(buffer)) length = sizeof(buffer) - 1;

  memcpy(buffer, data, length);

  printf("I2C sending: %.*s\r\n", length, buffer);

  // Send over I2C
  HAL_I2C_Master_Transmit(&hi2c3, (BLE_I2C_ADDRESS << 1), buffer, length, HAL_MAX_DELAY);

}

/**
  * @brief
  * @param None
  * @retval None
  */
void Enter_StandByMode(void)
{
    //HAL_PWREx_EnterSTOP2Mode(PWR_LOWPOWERREGULATOR_ON);
    HAL_PWR_EnterSTANDBYMode();
}


/**
  * @brief Read temperature and humidity from SHT40
  * @retval None
  */
void Measure(void)
{
  HAL_GPIO_WritePin(GPIOA, ENABLE_SENSOR_Pin, GPIO_PIN_SET);		// POWER ON SENSORS: PIN1 = LTR329
  HAL_Delay(100);													// Min. delay of 100ms after power on for LTR329
  LTR329_Init();													// After every RESET, do an Init
  HAL_Delay(500);													// Look at datasheet of LTR329 for this delay!!
  Read_SHT40();														// Measure temp & humidity
  Read_LTR329(&visible_plus_ir, &ir);								// Measure light
  HAL_GPIO_WritePin(GPIOA, ENABLE_SENSOR_Pin, GPIO_PIN_RESET);		// POWER OFF SENSORS: PIN1 = LTR329
}

/**
  * @brief Read temperature and humidity from SHT40
  * @retval None
  */
void Read_SHT40(void)
{
  printf("Read out SHT40 : \r\n");


  // Send measurement command
  if (HAL_I2C_Master_Transmit(&hi2c1, SHT40_ADDRESS, read_command, 1, HAL_MAX_DELAY) != HAL_OK)
  {
    Error_Handler();
  }

  HAL_Delay(10); // Wait for measurement to complete

  // Read measurement data
  if (HAL_I2C_Master_Receive(&hi2c1, SHT40_ADDRESS, sensor_data, 6, HAL_MAX_DELAY) != HAL_OK)
  {
    Error_Handler();
  }

  // Convert raw data to temperature and humidity
  uint16_t temp_raw = (sensor_data[0] << 8) | sensor_data[1];
  uint16_t humidity_raw = (sensor_data[3] << 8) | sensor_data[4];

  temperature = -45.0 + (175.0 * temp_raw / 65535.0);  // Formula from SHT40 datasheet
  humidity = 100.0 * humidity_raw / 65535.0;

  // Output data (use UART or another method to view values)
  printf("Temperature: %d°C, Humidity: %d%%\r\n", (int) temperature, (int) humidity);

}

/**
 * @brief Initialize the LTR-329 sensor
 */
void LTR329_Init(void)
{
    uint8_t config[2];

    printf("Begin init LTR329\r\n");


    // Set control register to enable sensor
    config[0] = LTR329_CONTR_REG;
    config[1] = 0x01; // Power ON, ALS (Ambient Light Sensing) enabled
    if (HAL_I2C_Master_Transmit(&hi2c1, LTR329_ADDRESS, config, 2, HAL_MAX_DELAY) != HAL_OK)
    {
        Error_Handler(); // Handle errors
    }

    // Set measurement rate (e.g., 500ms, gain 1)
    config[0] = LTR329_MEAS_RATE;
    config[1] = 0x11; // Integration time: 100ms, Measurement rate: 500ms
    if (HAL_I2C_Master_Transmit(&hi2c1, LTR329_ADDRESS, config, 2, HAL_MAX_DELAY) != HAL_OK)
    {
        Error_Handler(); // Handle errors
    }


}

/**
 * @brief Read light data from LTR-329
 * @param visible_plus_ir Pointer to store Visible + IR light data
 * @param ir Pointer to store IR-only light data
 */
void Read_LTR329(uint16_t *visible_plus_ir, uint16_t *ir)
{
	printf("Read out LTR329 : \r\n");


    uint8_t buffer[4];

    // Read 4 bytes of data (CH1 and CH0, low and high bytes)
    if (HAL_I2C_Mem_Read(&hi2c1, LTR329_ADDRESS, LTR329_DATA_CH1_LOW, I2C_MEMADD_SIZE_8BIT, buffer, 4, HAL_MAX_DELAY) != HAL_OK)
    {
        Error_Handler(); // Handle errors
    }

    // Combine low and high bytes for each channel
    *ir = (buffer[1] << 8) | buffer[0];               // CH1 (IR data)
    *visible_plus_ir = (buffer[3] << 8) | buffer[2];  // CH0 (Visible + IR data)

    // Print the data via UART or debugging interface
    printf("Visible + IR: %d, IR: %d\r\n", *visible_plus_ir, *ir);


}


/**
 * @brief
 */
void DriveToNextPoint(void)
{
	//printf("Drive to next point\r\n");
	char driveCommand[] = "2next\r\n";

	HAL_UART_Transmit(&huart1, (uint8_t*)driveCommand, strlen(driveCommand), 100);
}


void TurnOnBLE(void)
{
	printf("Turn on BLE\r\n");
	HAL_GPIO_WritePin(GPIOA, BLE_WAKE_Pin, GPIO_PIN_RESET);
	HAL_Delay(200);
	HAL_GPIO_WritePin(GPIOA, BLE_WAKE_Pin, GPIO_PIN_SET);
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
